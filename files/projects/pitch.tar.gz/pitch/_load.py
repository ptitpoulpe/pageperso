# -*- coding: utf-8 -*-
import re

def do_command(b,txt,src,trg,priv):
	
	try:
		lru, cmd, mod = re.findall(r'^(\w+)(?:\s+)(\w+)(?:\s+)?(\w+)?',txt)[0]
	except:
		b.send(src,trg,"Mauvais arguments",priv)
	else:	
		if (lru=='load'):
			b.send(src,trg,"Chargement du module: %s"%mod,priv)
			if b.load_module(cmd,mod):
				b.send(src,trg,"Chargement du module reussie: %s"%mod,priv)
			else:
				b.send(src,trg,"Echec lors du chargement du module: %s"%mod,priv)
		elif (lru=='reload'):
			b.send(src,trg,"Rechargement du module: %s"%cmd,priv)
			if b.reload_module(cmd):
				b.send(src,trg,"Rechargement du module reussie: %s"%cmd,priv)
			else:
				b.send(src,trg,"Echec lors du rechargement du module: %s"%cmd,priv)
		elif (lru=='unload'):
			b.send(src,trg,"Dechargement du module: %s"%cmd,priv)
			if b.unload_module(cmd):
				b.send(src,trg,"Dechargement du module reussie: %s"%cmd,priv)
			else:
				b.send(src,trg,"Echec lors du dechargement du module: %s"%cmd,priv)
		else:
			b.send(src,trg,"Mauvais arguments",priv)
	

def get_help(src,nom):
	msg  = "!%-25s: charge le module mod\n"%(nom+' load cmd mod')
	msg += "!%-25s: recharge le module cmd\n"%(nom+' reload cmd')
	msg += "!%-25s: decharge le module cmd\n"%(nom+' unload cmd')
	return msg
