import re
from pitchtools import fill

en_creation = {}
nb_votes = 0
votes= []

def do_command(b,txt,src,trg,priv):
	global votes
	global nb_votes
	global en_creation
	msg = ''
	try:
		cmd, txt = re.findall(r'^(\w+)\s*(.*)',txt)[0]
	except:
		b.send(src,trg,"Mauvais arguments",priv)
	else:
		if (cmd=='make'):
			if en_creation.has_key(src):
				en_creation[src][1].append((txt,[]))
				msg = 'Votre reponse a ete prise en compte'
			else:
				en_creation[src] = (txt,[])
				msg = 'Votre question a ete prise en compte'
		elif (cmd=='publish'):
			if en_creation.has_key(src):
				if len(votes) >10:
					votes = votes[1:9] + [en_creation[src]]
				else:
					votes.append(en_creation[src])
				del en_creation[src]
				nb_votes += 1
				msg = 'Votre questionnaire a ete publie'
			else:
				msg = 'vous n\'avez pas fait de questionnaire'
		elif (cmd=='list'):
			msg = fill("Liste des votes")
			for i in range(len(votes)):
				msg += '%d - %s\n'%(i+nb_votes-len(votes),votes[i][0])
			msg += '#'*60
		elif (cmd=='show'):
			try:
				id_vote = re.findall(r'^(\d+)',txt)[0]
				vote = votes[int(id_vote)-nb_votes+len(votes)]
			except:
				msg = 'id de vote invalide'
			else:
				msg += fill('vote %s'%id_vote)
				msg += 'Question: %s\n'%vote[0]
				reps = vote[1]
				for i in range(len(reps)):
					msg += 'Reponse %d (%d votes): %s\n'%(i,len(reps[i][1]),reps[i][0])
				msg += '#'*60
		elif (cmd=='ans'):
			try:
				id_vote, id_rep = re.findall(r'^(\d+)\s+(\d+)',txt)[0]
				vote = votes[int(id_vote)-nb_votes+len(votes)]
				votants = []
				for rep in vote[1]:
					votants.extend(rep[1])
				if src in votants:
					msg = 'Vous avez deja repondu a ce vote'
				else:
					vote[1][int(id_rep)][1].append(src)
					msg = 'Votre vote a ete pris en compte'
			except:
				msg += 'Mauvais arguments'
		else:
			msg += 'Mauvais arguments'
	b.send(src,trg,msg,priv)

def get_help(src,nom):
	msg = "!%-25s: creer un questionnaire premier appel cree la question et les autres les reponse\n"%(nom+' make q|a')
	msg += "!%-25s: publie la question\n"%(nom+' publish')
	msg += "!%-25s: list\n"%(nom+' list')
	msg += "!%-25s: affiche le questionnaire avec ces resultats\n"%(nom+' show id')
	msg += "!%-25s: donne une reponse a une question\n"%(nom+' ans id ans') 
	return msg

