# -*- coding: utf-8 -*- 
from ircbot import SingleServerIRCBot
from pitchtools import *
import re, datetime

class SuperBot(SingleServerIRCBot):
	def __init__(self, channel, nickname, server, port=6667):
		SingleServerIRCBot.__init__(self, [(server, port)], nickname, nickname)
        	self.channel = channel
		self.modules = {}
		self.unload_modules = {}

	def get_version(self):
		return "Pitchoune v0.1 Waouf Waouf Waouf"

	def send(self,src,trg,msgs,priv):
		src = nm_to_n(src)
		c = self.connection
		to = src if priv else trg 
		for line in msgs.split('\n'):
			c.privmsg(to,line)

	def load_module(self,cmd,name):
		if '_'+name in [m.__name__ for m in self.modules.values()]:
			return False
		print 'Charge le module: %s'%name
		try:
			if self.unload_modules.has_key('_'+name):
				reload(self.unload_modules['_'+name])
				self.modules[cmd] = self.unload_modules['_'+name]
				del self.unload_modules['_'+name]
			else:
				self.modules[cmd] = __import__('_'+name)			
		except Exception, e:
			print 'Erreur lors du chargement de: %s'%name
			print e
			return False
		else:
			print 'Chargement du module reussie: %s'%name
			return True

	def unload_module(self,cmd):
		print 'Decharge le module: %s'%cmd
		if self.modules.has_key(cmd) :
			self.unload_modules[self.modules[cmd].__name__] = self.modules[cmd]
			del self.modules[cmd]
			print 'Dechargement du module reussie: %s'%cmd
			return True
		else:
			print 'Erreur lors du dechargement de: %s'%cmd
			return False

	def reload_module(self,cmd):
		print 'Recharge le module: %s'%cmd
		if self.modules.has_key(cmd) :
			reload(self.modules[cmd])
			print 'Rechargement du module reussie: %s'%cmd
			return True
		else:
			print 'Erreur lors du rechargement de: %s'%cmd
			return False

	def on_nicknameinuse(self, c, e):
        	c.nick(c.get_nickname() + "_")

	def on_welcome(self, c, e):
		c.join(self.channel)
		self.lastsend=datetime.datetime.now()

	def on_pubmsg(self, c, e):
		self.do_command(c,e)

	def on_privmsg(self, c, e):
		self.do_command(c,e)

	def on_pubnotice(self, c, e):
		self.do_command(c,e)

	def on_privnotice(self, c, e):
		self.do_command(c,e)

	def do_command(self,c,e):
		try:
			src = e.source()#.split('!')[0]
			priv, cmd, txt = re.findall(r'^(!|\?)(\w+)(?:\s+(.*))?',e.arguments()[0])[0]
			priv = (priv=='!') or (e.eventtype()=='privmsg') or (e.eventtype()=='privnotice')
			trg = e.target()
		except Exception, e:
			pass
		else:
			if (datetime.datetime.now() - self.lastsend).seconds > 3:
				self.lastsend=datetime.datetime.now()
				try:
					print self.modules[cmd]
					self.modules[cmd].do_command(self,txt,src,trg,priv)
				except Exception, e:
					print e
					self.send(src,trg,'Commande Inexistante',True)
				

#Event
#arguments(), eventtype(), source(), target()
#ServerConnection
#bot.connection.join(channel)
#bot.connection.privmsg(channel, text)
#bot.connection.notice(target,text)
#bot.connection.privmsg_many(targets, text)

pitchoune = SuperBot('#linux','Pitchoune','esialnet.homelinux.net')
pitchoune.load_module('help','help')
pitchoune.load_module('mod','load')
pitchoune.load_module('admin','admin')
pitchoune.modules['admin'].admin_mod('mod',pitchoune.modules['mod'])
pitchoune.start()
