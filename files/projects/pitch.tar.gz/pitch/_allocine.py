# -*- coding: utf-8 -*- 
import urllib,re,datetime
from HTMLParser import HTMLParser
from pitchtools import fill

class Movie:
	def __init__(self,affiche, titre, type, duree, realisateur, acteurs, presse, spectateurs, resume, horaires):
		self.affiche = affiche
		self.titre = titre
		self.type = type
		self.duree = duree
		self.realisateur = realisateur
		self.acteurs = acteurs
		self.presse = presse
		self.spectateurs= spectateurs
		self.resume = resume
		self.horaires = horaires

	def __str__(self):
		str = fill(self.titre) + '\n'
		#str += 'AFFICHE: %s\n'%self.affiche
		#str += 'TITRE: %s\n'%self.titre
		str += 'TYPE: %s\n'%self.type
		str += 'DUREE: %s\n'%self.duree
		str += 'REALISATEUR: %s\n'%self.realisateur
		str += 'ACTEURS:\n'
		for acteur in self.acteurs:
			str += '   %s\n'%acteur
		str += 'PRESSE: %s/5\n'%self.presse
		str += 'SPECTATEURS: %s/5\n'%self.spectateurs
		str += 'RESUME: %s\n'%self.resume
		str += 'HORAIRES:\n'
		for horaire in self.horaires:
			str += '   %s : %s\n'%horaire
		str += '#'*60 + '\n'
		return str

class AlloCineParser:
	parseAll = re.compile('<a class="link1".*?><img src="(.*?)".*?/></a>.*?<a class="link1".*?>(.*?)</a>.*?<h5>(.*?) \((.*?)\)</h5>.*?De <a class="link1".*?>(.*?)</a>.*?Avec ((?:<a class="link1".*?>.*?</a>.*?)+)</h4>.*?(?:Presse.*?class="etoile_(\d).*?)?(?:Spectateur.*?class="etoile_(\d).*?)?<h5>(.*?)</h5>.*?<h4 style="color:#D20000">(.*?)</h4>').findall
	parseActeurs = re.compile('<a.*?>(.*?)</a>').findall
	parseHoraires = re.compile('([^<>]*?) : <b>(.*?)</b>').findall

	def __init__(self,url,nom='AlloCine'):
		self.url = url
		self.nom = nom
		self.movies = []
		self.forceUpdateInfos()
	
	def getWebPage(self):
		tmp = urllib.urlopen(self.url)
		html = tmp.read()
		tmp.close()
		return html

	def getMoviesList(self):
		ml = fill(self.nom) + '\n'
		for i in range(len(self.movies)):
			ml += '%d - %s\n'%(i,self.movies[i].titre)
		ml += '#'*60 + '\n'
		return ml

	def getMovie(self,i):
		try:
			return fill(self.nom) + '\n' + str(self.movies[i])
		except:
			return 'id de film invalide'

	def updateInfos(self):
		if (datetime.datetime.now() - self.lastUpdate).seconds > 3600:
			self.forceUpdateInfos()

	def forceUpdateInfos(self):
		self.movies = []
		for infos in self.parseAll(self.getWebPage()):
			self.movies.append(Movie(infos[0],infos[1],infos[2],infos[3],infos[4],self.parseActeurs(infos[5]),
						 infos[6],infos[7],infos[8],self.parseHoraires(infos[9])))
		self.lastUpdate = datetime.datetime.now()

#ac = AlloCineParser('http://www.allocine.fr/seance/salle_gen_csalle=P0108.html')
#ac.updateInfos()
#print ac.getMoviesList()
#print ac.getMovie(0)

acl = [AlloCineParser('http://www.allocine.fr/seance/salle_gen_csalle=P0108.html','Cameo St Seb'),
       AlloCineParser('http://www.allocine.fr/seance/salle_gen_csalle=P0073.html','Cameo'),
       AlloCineParser('http://www.allocine.fr/seance/salle_gen_csalle=P0090.html','Kinépolis'),
       AlloCineParser('http://www.allocine.fr/seance/salle_gen_csalle=P0090.html','UGC St Jean')]

def do_command(b,txt,src,trg,priv):
	cid, mid = re.findall(r'^(\d+)?(?:\s+)?(\d+)?',txt)[0]
	msg = ''
	try:
		ac = acl[int(cid)]
	except:
		msg = fill('Cinemas') 
		for i in range(len(acl)):
			msg += '%d - %s\n'%(i,acl[i].nom)
		msg += '#'*60
	else:
		try:
			mv = ac.getMovie(int(mid))
		except:
			msg = ac.getMoviesList()
		else:
			msg = str(mv)
	b.send(src,trg,msg,priv)

def get_help(src,nom):
	msg  = "!%-25s: donne la liste des cinémas avec leur identifiants\n"%nom
	msg += "!%-25s: donne la liste des films d'un cinéma\n"%(nom + ' id_cine')
        msg += "!%-25s: donne les horaires et la description d'un film dans un cinema\n"%(nom+' id_cine id_film')
	return msg



