import re
admins = []
admin_modules = {}
mdp = 'truc'

#mettre un decorateur sur __del__

def do_command(b,txt,src,trg,priv):
	try:
		cmd, arg = re.findall(r'^(\w+)(?:\s+)(\w+)',txt)[0]
	except:
		b.send(src,trg,"Mauvais arguments",priv)
	else:
		if (cmd=='log'):
			if arg == mdp and src not in admins:
				admins.append(src)
		elif (cmd=='admod'):
			if b.modules.has_key(arg):
				if not admin_mod(arg,b.modules[arg]):
					b.send(src,trg,"Module inexistant",priv)
		elif (cmd=='unadmod'):
			if b.modules.has_key(arg):
				if not unadmin_mod(arg,b.modules[arg]):
					b.send(src,trg,"Module inexistant ou pas admin",priv)
		else:
			b.send(src,trg,"Mauvais arguments",priv)

def get_help(src,nom):
	msg = "!%-25s: permet de devenir admin\n"%(nom+' log')
	if src in admins:
		msg += "!%-25s: permet de rendre un module admin\n"%(nom+' admod')
		msg += "!%-25s: permet de rendre un module normal\n"%(nom+' unadmod')
	return msg

def admin_mod(cmd,module):
	if not admin_modules.has_key(cmd):
		dc = module.do_command
		gh = module.get_help
		admin_modules[cmd] = (dc,gh)
		module.do_command = AdminDoCommand(dc,admins)
		module.get_help = AdminGetHelp(gh)
		return True
	else:
		return False

def unadmin_mod(cmd,module):
	if admin_modules.has_key(cmd):
		module.do_command = admin_modules[cmd][0]
		module.get_help = admin_modules[cmd][1]
		del admin_modules[cmd]

class AdminDoCommand:
	def __init__(self,func, admins):
		self.func = func
		self.admins = admins

	def __call__(self,*args):
		b,txt,src,trg,priv = args
		if src in admins:
			return self.func(*args)
		else:
			b.send(src,trg,'Commande reserve aux admins',priv)

class AdminGetHelp:
	def __init__(self,func):
		self.func = func

	def __call__(self,*args):
		src,nom = args
		if src in admins:
			return self.func(*args)
		else:
			return ''

class Admin__del__:
	def __init__(self,func,admins,nom):
		self.admins = admins
		self.func = func
		self.nom = nom
	def __call__(self,*args):
		del self.admins[self.nom]
		return self.func(*args)
