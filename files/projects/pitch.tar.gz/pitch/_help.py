# -*- coding: utf-8 -*- 
from pitchtools import fill

def do_command(b,txt,src,trg,priv):
	msg = fill("Message d'aide")
	for nom, module in b.modules.items():
		msg += module.get_help(src,nom)
	msg += "#"*60
	b.send(src,trg,msg,priv)

def get_help(src,nom):
	return "!%-25s: affiche ce message\n"%nom
