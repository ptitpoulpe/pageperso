#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import itertools as it
import sys

def chicks(k, b, t, cs):
#    print k, b, t, cs
    poss = 0
    ncs = []
    for x, v in cs:
        if x+v*t>=b:
            ncs.append((x, True))
            poss += 1
        else:
            ncs.append((x, False))
    if k>poss:
        return 'IMPOSSIBLE'
    ncs.sort(reverse=True)
    res = 0
    done = 0
    bads = 0
    for _, ok in ncs:
        if done==k:
            return res
        if ok:
            res += bads
            done += 1
        else:
            bads += 1
    return res

nb = int(sys.stdin.readline())
for i in range(nb):
    n, k, b, t = map(int, sys.stdin.readline().split(' '))
    cs = zip(map(int, sys.stdin.readline().split(' ')),
             map(int, sys.stdin.readline().split(' ')))
    res = chicks(k, b, t, cs)
    print "Case #%i: %s"%(i+1, res) 

