#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import itertools as it
import sys


def mkdir(fs, newdir):
    #print newdir
    n = 0
    for i in filter(None, newdir.split('/')):
        if i in fs:
            fs = fs[i]
        else:
            fs[i] = {}
            fs = fs[i]
            n += 1
    return n

nb = int(sys.stdin.readline())
for i in range(nb):
    b, n = map(int, sys.stdin.readline().split(' '))
    fs = {}
    for j in range(b):
        mkdir(fs, sys.stdin.readline().strip())
    #print '--'
    res = sum(mkdir(fs, sys.stdin.readline().strip()) for j in range(n))
    print "Case #%i: %i"%(i+1, res) 

