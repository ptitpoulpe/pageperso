#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import itertools as it
import math
import sys

def elegant(k, diamond):
    i = bigest_elegant(k, diamond)
    res = 0
    for i in range(k-i):
        res += k
        k += 1
    return res

def bigest_elegant(k, diamond):
    for s in range(k,1,-1):
        if is_elegant(k, 0, 0, diamond) or \
           is_elegant(k, k-s, k-s, diamond) or \
           is_elegant(k, 0, k-s, diamond) or \
           is_elegant(k, k-s, 0, diamond):
            return s
    return 1

def is_elegant(k, i, j, diamond):
    for si in range(k):
        for sj in range(max(si, k-si)):
            d = diamond[i+si][j+sj]
            if not (d==diamond[i+sj][j+si] and
                    d==diamond[i+k-si][i+k+sj] and
                    d==diamond[i+k-sj][i+k-si]):
                return False
    return True

nb = int(sys.stdin.readline())
for i in range(nb):
    k = int(sys.stdin.readline())
    diams = [[] for i in range(k)]
    for i in range(k):

        l = (int(i) for i in sys.stdin.readline().strip().split(' '))
        for j, e in enumerate(l):
            if i<=k:
                diams[j].append(e)
            else:
                diams[j+i-k].append(e)
    print diams
    res = elegant(k, diams)
    #print lines
    print "Case #%d: %d"%(i+1, res)
