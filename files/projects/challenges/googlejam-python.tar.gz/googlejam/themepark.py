#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import itertools as it
import sys

# gérer le cas ou start n'est pas 0
def money(k, gs):
    igs = it.cycle(enumerate(gs))
    s, i = igs.next()
    for e, g in igs:
        if i+g<=k and e!=s:
            i += g
        else:
            yield i            
            if e==0:
                return
            s, i = e, g

def money_r(r, k, gs):
    #print list(it.islice(it.cycle(money(k, gs)), r))
    return sum(it.islice(it.cycle(money(k, gs)), r))

def money2_r(r, k, gs):
    #print list(it.islice(it.cycle(money(k, gs)), r))
    res = list(it.islice(money(k, gs), r))
    d, m = divmod(r, len(res))
    r = sum(res)
    return d*r + sum(res[:m])

def money3_r(r, k, gs):
    # get the first loop
    res = []
    starts = set()
    igs = it.cycle(enumerate(gs))
    s, i = igs.next()
    while igs is not None and len(res)<=r:
        e, g = igs.next()
        if i+g<=k and e!=s:
            i += g
        else:
            res.append((s,i))
            starts.add(s)
            if e in starts:
                igs = None
            s, i = e, g
    nums, res = zip(*res)
    i = nums.index(s) if igs is None else 0
    head = res[:i]
    tail = res[i:]
    d, m = divmod(r-len(head), len(tail))
    mh = sum(head)
    mt = sum(tail)
    return mh + d*mt + sum(tail[:m])


nb = int(sys.stdin.readline())
for i in range(nb):
    l1 = sys.stdin.readline()
    l2 = sys.stdin.readline()
    r, k, n = map(int, l1.split(' '))
    gs =  map(int, l2.split(' '))
    #print r, k, gs
    print "Case #%d: %d"%(i+1, money3_r(r, k, gs))
