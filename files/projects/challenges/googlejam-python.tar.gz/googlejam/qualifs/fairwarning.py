#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import itertools as it
import sys

def pgcd(a, b):
  if b == 0:
    return a
  return pgcd(b, a % b)

def fairwarning(ges):
  fge = ges[0]
  fgediffs = (abs(ge - fge) for ge in ges)
  apo = reduce(pgcd, fgediffs)
  if fge % apo == 0:
    return 0
  else:
    return apo - (fge % apo)
