#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import sys

nb = int(sys.stdin.readline())

for i, l in zip(range(nb), sys.stdin.readlines()):
    k, n = map(int, l.split(' '))
    n = bin(n)
    print "Case #%d: %s"%(i+1, "ON" if len(n)>=(k+2) and all(e=='1' for e in n[-k:]) else "OFF")
