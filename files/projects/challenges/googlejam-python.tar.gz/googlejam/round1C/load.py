#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import itertools as it
import math
import sys

def load(l, p, c):
    i = 0
    while l*c<p:
        i += 1
        c *= c
    return i


nb = int(sys.stdin.readline())
for i in range(nb):
    l, p, c = (int(i) for i in sys.stdin.readline().split(' '))
    res = load(l, p, c)
    #print lines
    print "Case #%d: %d"%(i+1, res)
