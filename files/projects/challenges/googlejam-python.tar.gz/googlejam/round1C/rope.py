#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import itertools as it
import bisect
import sys
from decimal import Decimal

def rope(lines):
    lines.sort()
    done = []
    ints = set()
    for a, b in lines:
        i = bisect.bisect(done, (b, a))
        for xb, xa in done[i:]:
            #print xa, xb, a, b
            nx = Decimal(a - xa) / Decimal((xb-xa) - (b-a))
            ny = Decimal(b - a)*nx + Decimal(a)
            ints.add((nx, ny))
        done.insert(i, (b,a))
    return len(ints)


nb = int(sys.stdin.readline())
for i in range(nb):
    n = int(sys.stdin.readline())
    lines = []
    for j in range(n):
        a, b = (int(i) for i in sys.stdin.readline().split(' '))
        lines.append((a, b))
    res = rope(lines)
    #print lines
    print "Case #%d: %d"%(i+1, res)
