#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import itertools as it
import sys

def ipacket(it, size=5):
    """ ipacket([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 3)
        => [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]"""
    res = []
    for e in it:
        if len(res)==size:
            yield res
            res = [e]
        else:
            res.append(e)
    if res:
        yield res

def smooth(d, i, m, l, fv):
    if not l:
        return 0
    best = smooth(d, i, m, l[:-1], fv) + d
    for pv in range(256):
        prev_cost = smooth(d, i, m, l[:-1], pv)
        move_cost = abs(fv - l[-1])
        num_insert = (abs(fv-pv)-1)/m
        insert_cost = num_insert * i
        best = min(best, prev_cost + move_cost + insert_cost)
    return best    

#int Solve(pixels[], final_value) {
#    if (pixels is empty) return 0
#
#    // Try deleting
#    best = Solve(pixels[1 to N-1], final_value) + D
#
#    // Try all values for the previous pixel value
#    for (all prev_value) {
#      prev_cost = Solve(pixels[1 to N-1], prev_value)
#      move_cost = |final_value - pixels[N]|
#      num_inserts = (|final_value - prev_value| - 1) / M
#      insert_cost = num_inserts * I
#      best = min(best, prev_cost + move_cost + insert_cost)
#    }
#    return best
#  }«

print min(smooth(6, 6, 2, [1, 7, 5], i) for i in range(256))
print min(smooth(100, 1, 5, [1, 50, 7], i) for i in range(256))

nb = int(sys.stdin.readline())
for i in range(nb):
    n, k = (int(i) for i in sys.stdin.readline().split(' '))
    table = [sys.stdin.readline() for j in range(n)]
    t = Table(i+1, k, table)
    t.print_result()
