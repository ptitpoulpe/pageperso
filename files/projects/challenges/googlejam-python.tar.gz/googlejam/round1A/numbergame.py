#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import itertools as it
import sys

memo = {}
def winningposition(a, b):
    a,b = sorted((a,b))
    if (a,b) in memo:
        return memo[(a,b)]
    if b>=2*a:
        return True
    for k in reversed(range(b/a)):
        nb = b - (k+1)*a
        if nb!=0:
            if not winningposition(nb, a):
                memo[(a,b)] = True
                return True
    memo[(a,b)] = False
    return False

def winningposition(a, b):
    if a == 0: return True
    if b >= 2*a: return True
    return not winningposition(a-b, a)
#bool winning(int A, int B) {
#    if (B == 0) return true;
#    if (A >= 2*B) return true;
#    return !winning(B, A-B);
#  }

def num_winning_positions(a1, a2, b1, b2):
    return sum(winningposition(*sorted((a,b))) 
               for a in range(a1,a2+1)
               for b in range(b1,b2+1))

#print winningposition(5,8)
#print '---'
#print winningposition(2,11)
#print '---'
#print num_winning_positions(1, 6, 1, 6)



nb = int(sys.stdin.readline())
for i in range(nb):
    a1, a2, b1, b2 = map(int, sys.stdin.readline().split(' '))
    print a1, a2, b1, b2
    res = num_winning_positions(a1, a2, b1, b2)
    print "Case #%i: %i"%(i+1, res) 

