#!/usr/bin/env python2
# -*- coding: utf-8 -*-

import itertools as it
import sys

class Table(object):

    def __init__(self, id, k, text):
        self.id = id
        self.table = []
        self.num_columns = 0
        self.num_lines = 0
        self.k = k
        for column in text:
            self.add_column()
            for token in reversed(column):
                if token in 'RB':
                    self.add_token_last_column(token)

    def add_column(self):
        self.table.append([])
        self.num_columns += 1

    def add_token_last_column(self, token):
        self.table[-1].append(token)
        self.num_lines = max(self.num_lines, len(self.table[-1]))

    def get_elem(self, i, j):
        if 0<=i<len(self.table) and 0<=j<len(self.table[i]):
            return self.table[i][j]
        else:
            return None

    def check_all(self):
        winner = set()
        for i in range(self.num_columns):
            for j in range(self.num_lines):
                key = self.get_elem(i,j)
                if self.check(key,i,j,0,1) or self.check(key,i,j,1,0) or \
                   self.check(key,i,j,1,1) or self.check(key,i,j,1,-1):
                    winner.add(key)
        if None in winner:
            winner.remove(None)
        return winner

    def check(self, key, i, j, si, sj):
        for k in range(1, self.k):
            if self.get_elem(i+k*si, j+k*sj)!=key:
                return False
        return True

    def print_result(self):
        res = self.check_all()
        print "Case #%d:"%self.id,
        if len(res)==2:
            print "Both"
        elif len(res)==0:
            print "Neither"
        elif len(res)==1:
            res = res.pop()
            if res=='R':
                print "Red"
            else:
                print "Blue"


nb = int(sys.stdin.readline())
for i in range(nb):
    n, k = (int(i) for i in sys.stdin.readline().split(' '))
    table = [sys.stdin.readline() for j in range(n)]
    t = Table(i+1, k, table)
    t.print_result()
