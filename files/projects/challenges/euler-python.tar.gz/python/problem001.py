print sum(frozenset(range(0,1000,3)+range(0,1000,5)))
