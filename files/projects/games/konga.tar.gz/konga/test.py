#!/usr/bin/env python

class note:
    def __init__(self,temps):
        self.gauche = False
        self.droit = False
        self.clap = False
        self.temps=temps
        
    def valide_gauche(self):
        self.gauche = True

    def valide_droit(self):
        self.droit = True

    def valide_clap(self):
        self.clap = True

    def est_valide(self):
        return False

    def image(self):
        return 0

class clap(note):
    def __init__(self,temps):
        note.__init__(self,temps)

    def est_valide(self):
        return self.clap

    def image(self):
        return 1

class clap_gauche(note):
    def __init__(self,temps):
        note.__init__(self,temps)

    def est_valide(self):
        return self.gauche

    def image(self):
        return 2

class clap_droit(note):
    def __init__(self,temps):
        note.__init__(self,temps)

    def est_valide(self):
        return self.droit

    def image(self):
        return 3

class double_clap(note):
    def __init__(self,temps):
        note.__init__(self,temps)

    def est_valide(self):
        return self.gauche and self.droit

    def image(self):
        return 4

import sys, pygame
pygame.init()
speed = 5

size = width, height = 1000, 70
brown= 150,75,50
pos_clap = 50

notesb = [(2,4700), (2,5300), (2,5900), (2,6100), (2,6300), (3,6900), (3,7500), (3,8100), (3,8300), (3,8500), (4,9100), (1,9700), (1,10172)]

#notesb += range(35000,100000,5000)
notes = []
for i in notesb:
    if i[0]==1:
        notes += [clap(i[1])]
    elif i[0]==2:
        notes += [clap_gauche(i[1])]
    elif i[0]==3:
        notes += [clap_droit(i[1])]
    elif i[0]==4:
        notes += [double_clap(i[1])]
notes_ = []

screen = pygame.display.set_mode(size)

claps_image = [pygame.image.load("clap_vide.png"),
                pygame.image.load("clap.png"),
                pygame.image.load("clap_gauche.png"),
                pygame.image.load("clap_droit.png"),
                pygame.image.load("double_clap.png")]
clap_vide = claps_image[0] 
ok = pygame.image.load("ok.png")
claps_size = claps_image[0].get_size()
ok_size = ok.get_size()

pygame.mixer.music.load("gc.mp3")
pygame.mixer.music.play()

bon = 0
combos = 0
while 1:
    pos = pygame.mixer.music.get_pos()
    for event in pygame.event.get():
        if event.type == pygame.QUIT: sys.exit()
        if event.type == pygame.KEYDOWN :
##            notes_ += [(1,pos)]
##            print notes_
            for i in notes:
                if abs((i.temps-pos)/speed-pos_clap) < 20:
                    if pygame.key.get_pressed()[274]:
                        i.valide_clap()
                    if pygame.key.get_pressed()[275]:
                        i.valide_droit()
                    if pygame.key.get_pressed()[276]:
                        i.valide_gauche()
                    if i.est_valide():
                        bon = 50
                        combos += 1
##                        print abs((i.temps-pos)/speed-pos_clap)
##                        print "nbr combos = " + str(combos)
                    
    screen.fill(brown)
    ballrect = pygame.Rect((pos_clap,20),claps_size)
    screen.blit(clap_vide, ballrect)        

    if pygame.font:
        font = pygame.font.Font(None, 30)
        text = font.render("Combos:"+str(combos), 1, (10, 10, 10))
        textpos = pygame.Rect((pos_clap+50,2),text.get_size())
        screen.blit(text, textpos)
        font = pygame.font.Font(None, 20)
        text = font.render("jaune=gauche,rouge=droite,violet=les deux,bleu=bas.", 1, (10, 10, 10))
        textpos = pygame.Rect((pos_clap+160,2),text.get_size())
        screen.blit(text, textpos)
        

    flag = True
    for i in notes:
        if flag and ((i.temps-pos)/speed-pos_clap+20)<0:
            if not i.est_valide():
                combos = 0
            else:
                notes = notes[1:]
        else:
            flag = False
        ballrect = pygame.Rect(((i.temps-pos)/speed,20),claps_size)
        screen.blit(claps_image[i.image()], ballrect)

    if bon > 0:
        bon -= 1
        ballrect = pygame.Rect((pos_clap+10,2),ok_size)
        screen.blit(ok, ballrect)

    pygame.display.flip()
