#!/usr/bin/env python
#fait par shenshei avec la collaboration de pini
import pygame,sys
from tableau import *
from graphique import *
pygame.init()

size = width, height = 360, 360

graphique = Graphique(size)
partie = Partie(graphique)

def afficher():
    print "========================="
    tab = partie.tableau
    for y in range(len(tab[0])):
        for x in range(len(tab)):
            if tab[x][y]==None:
                print "En position ("+str(x)+","+str(y)+") on a rien"
            else:
                print "En position ("+str(x)+","+str(y)+") on a ("+str(tab[x][y].abs)+","+str(tab[x][y].ord)+","+str(tab[x][y].forme)+")"

while True:
    event = pygame.event.wait()
    if event.type == pygame.QUIT: sys.exit()
    if event.type == pygame.KEYDOWN :
        if not partie.fin:
            if pygame.key.get_pressed()[275]:
                partie.bouger_droite()
            if pygame.key.get_pressed()[276]:
                partie.bouger_gauche()
            if pygame.key.get_pressed()[273]:
                partie.tourner()
            if pygame.key.get_pressed()[274]:
                partie.jouer_coup()
        else:
            if pygame.key.get_pressed()[13]:
                graphique.mettre_a_zero()
                partie = Partie(graphique)
        if pygame.key.get_pressed()[ord('q')]: sys.exit()
