import pygame
from pygame.locals import *

niveaux_images = []
for i in range(1,13):
    niveaux_images += [pygame.image.load("nivo"+str(i)+".png")]


class Forme(pygame.sprite.Sprite):
    tableau = None
    boxes = None
    def __init__(self, piece):
        pygame.sprite.Sprite.__init__(self)
        self.piece = piece
        self.piece.set_observer(self)
        self.image = niveaux_images[self.piece.forme-1]
        self.rect = None
        self.moved = True
        self.dirty = True

    def supprimer(self):
        Forme.tableau.remove(self)
        Forme.boxes.remove(self)

    def move(self):
        self.moved = True

    def changer_image(self):
        self.image = niveaux_images[self.piece.forme-1]
        self.moved = True

    def changer_taille_image(self,h,l):
        self.image = pygame.transform.scale(niveaux_images[self.piece.forme-1],
                                            (int(h),int(l)))

    def update(self,time):
        x = self.piece.abs
        y = self.piece.ord
        if self.moved:
            self.dirty = True
            if x<0:
                if y==-1:
                    self.rect=pygame.Rect((25,80),(26,32))
                elif y==-2:
                    self.rect=pygame.Rect((55,80),(26,32))
                self.moved = False
            else:
                dep = self.piece.deplacement(time)
                if dep==None:
                    self.moved=False
                    self.rect=pygame.Rect((110+(x)*30,330-(y)*30),(26,32))
                elif dep[2]==None:
                    self.moved=False
                    self.rect=pygame.Rect((0,0),(0,0))
                else:
                    if dep[2]!=1:
                        h = 26*dep[2]
                        l = 32*dep[2]
                        self.changer_taille_image(h,l)
                        self.rect=pygame.Rect((110+(x+dep[0])*30+(26-h)/2,330-(y+dep[1])*30+(32-l)/2),(h,l))
                    else:
                        self.rect=pygame.Rect((110+(x+dep[0])*30,330-(y+dep[1])*30),(26,32))

class Score(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.score = 0
        self.font = pygame.font.Font(None, 25)
        self.observed = None
        self.update(0)
        self.dirty = False
        
    def set_observed(self,observed):
        self.observed=observed
    
    def update(self,time):
        self.dirty = True
        if self.observed==None:
            score = 0
        else:
            score = self.observed.score
        self.image = self.font.render(str(score), 1, (10, 10, 10))
        text_size = self.image.get_size()
        self.rect = pygame.Rect((50-text_size[0]/2,48),text_size)           


class RenderDirty(pygame.sprite.RenderClear):
  def draw(self, surface):
    dirty = self.lostsprites
    self.lostsprites = []
    for s, r in self.spritedict.items():
      if not s.dirty:
        continue
      s.dirty = False
      newrect = surface.blit(s.image, s.rect)
      if r is 0:
        dirty.append(newrect)
      else:
        if newrect.colliderect(r):
          dirty.append(newrect.union(r))
        else:
          dirty.append(newrect)
          dirty.append(r)
      self.spritedict[s] = newrect
    return dirty

  def clear(self, surface, bgd):
    if callable(bgd):
      for r in self.lostsprites:
        bgd(surface, r)
      for s, r in self.spritedict.items():
        if s.dirty and r is not 0: bgd(surface, r)
    else:
      surface_blit = surface.blit
      for r in self.lostsprites:
        surface_blit(bgd, r, r)
      for s, r in self.spritedict.items():
        if s.dirty and r is not 0: surface_blit(bgd, r, r)

class Graphique:
    def __init__(self,size):
        self.screen = pygame.display.set_mode(size)
        self.tableau = []
        self.time = pygame.time
        Forme.tableau = self.tableau
        self.boxes = RenderDirty()
        self.fond = pygame.image.load("fond-ecran.png")
        self.fondrect = pygame.Rect((0,0),(360,360))
        self.afficher_fond()
        self.score = Score()
        self.boxes.add(self.score)
        Forme.boxes = self.boxes
        self.next = None

    def mettre_a_zero(self):
        self.tableau = []
        Forme.tableau = self.tableau
        self.boxes.empty()
        self.afficher_fond()
        self.boxes.add(self.score)
        self.next = None

    def fin(self):
        lost = pygame.image.load("perdu.png")
        rect = pygame.Rect((10,80),(300,198))
        self.screen.blit(lost,rect)
        pygame.display.flip()
    
    def ajouter(self,piece1,piece2):
        if self.next != None :
            self.tableau.append(self.next[0])
            self.tableau.append(self.next[1]) 
        self.next = (Forme(piece1),
                     Forme(piece2))
        self.boxes.add(self.next[0])
        self.boxes.add(self.next[1])

    def afficher_fond(self):
        self.screen.blit(self.fond,self.fondrect)
        pygame.display.flip()

    def afficher(self):
        moved = False
        self.boxes.update(self.time.get_ticks())
        self.boxes.clear(self.screen, self.fond)
        rectlist = self.boxes.draw(self.screen)
        pygame.display.update(rectlist)
        for forme in self.tableau:
            if forme.moved:
                moved = True
        if moved:
            pygame.time.delay(30)
            self.afficher()

        
