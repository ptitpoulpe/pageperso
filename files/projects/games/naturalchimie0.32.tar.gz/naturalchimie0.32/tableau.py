import random, math
random.seed()

#une case du tableau
class Piece:

    vitesse = 100
    
    def __init__(self,forme=1,abscisse=-1,ordonnee=-1):
        self.forme = forme
        self.mark = False
        self.abs = abscisse
        self.ord = ordonnee
        #self.deplacement = lambda : (0,0)
        self.observer = None
        #voir pour les pointers sur les fonction
        #et pour la generation de fonctions anonymes
        self.deplacement = None
        self.no_deplacement()
        self.dep_time = 0
        self.dep_desc = 0

    def set_observer(self,observer):
        self.observer = observer

    def maj(self,time):
        if self.observer!=None:
            self.observer.move()
        def anon(t):
            if t > time + Piece.vitesse*2:
                self.no_deplacement()
                return None
            else:
                return (0,0,1)
        self.deplacement = anon

    def changer_forme(self,forme,time):
        if self.observer!=None:
            self.observer.move()
        def anon(t):
            if t > time + Piece.vitesse*4:
                self.forme = forme
                self.observer.changer_image()
                def anon(t2):
                    if t2 > time + 2*Piece.vitesse*4:
                        self.no_deplacement()
                        return None
                    else:
                        return (0,0,float(t2 - time) / float(2*Piece.vitesse*4))
                self.deplacement = anon 
                return self.deplacement(t)
            else:
                return (0,0,1 - float(t - time) / float(Piece.vitesse*4))
        self.deplacement = anon

    def supprimer(self,time):
        if self.observer!=None:
            self.observer.move()
        def anon(t):
            if t > time + Piece.vitesse*4:
                self.no_deplacement()
                self.observer.supprimer()
                return (0,0,None)
            else:
                return (0,0,1 - float(t - time) / float(Piece.vitesse*4))
        self.deplacement = anon

    def marquer(self):
        self.mark = True

    def demarquer(self):
        self.mark = False

    def deplacer_en(self,abscisse,ordonnee):
        if self.observer!=None:
            self.observer.move()
        self.abs = abscisse
        self.ord = ordonnee
        
    def descendre(self,desc,time):
        if self.observer!=None:
            self.observer.move()
        def anon(t):
            if t > time + desc * Piece.vitesse:
                self.no_deplacement()
                return None
            else:
                return (0,desc - float(t - time) / float(Piece.vitesse),1)
        self.deplacement = anon
        self.ord -= desc

    def no_deplacement(self):
        def anon(time):
            return None
        self.deplacement = anon


    def gauche(self,time):
        if self.observer!=None:
            self.observer.move()
        def anon(t):
            if t > time + Piece.vitesse*2:
                self.no_deplacement()
                return None
            else:
                return (1 - float(t - time) / float(Piece.vitesse*2),0,1)
        self.deplacement = anon
        self.abs -= 1

    def droite(self,time):
        if self.observer!=None:
            self.observer.move()
        def anon(t):
            if t > time + Piece.vitesse*2:
                self.no_deplacement()
                return None
            else:
                return (float(t - time) / float(Piece.vitesse*2)-1,0,1)
        self.deplacement = anon
        self.abs += 1

    def haut(self,time):
        if self.observer!=None:
            self.observer.move()
        def anon(t):
            if t > time + Piece.vitesse*2:
                self.no_deplacement()
                return None
            else:
                return (0,float(t - time) / float(Piece.vitesse*2)-1,1)
        self.deplacement = anon
        self.ord += 1

    def bas(self,time):
        if self.observer!=None:
            self.observer.move()
        def anon(t):
            if t > time + Piece.vitesse*2:
                self.no_deplacement()
                return None
            else:
                return (0,1-float(t - time) / float(Piece.vitesse*2),1)
        self.deplacement = anon
        self.ord -= 1

    def tourner(self,time):
        if self.observer!=None:
            self.observer.move()
        def anon(t):
            if t > time + Piece.vitesse*2:
                self.no_deplacement()
                return None
            else:
                return (math.sin(float(t - time) / float(Piece.vitesse*2))-1,
                        math.cos(float(t - time) / float(Piece.vitesse*2)),1)
        self.deplacement = anon
        self.ord -= 1
        self.abs += 1

#le tableau de jeu
class Partie:
    def __init__(self,observer):
        self.observer = observer
        self.observer.score.set_observed(self)
        self.tableau = [[None for _ in range(7+4)] for _ in range(7)]
        self.nb_niveaux = 12
        self.niveaux_debloque = 4
        self.score = 0
        self.score_tmp = 0
        self.enchainements = 0
        self.pos = [3,True] #colonne puis paysage ou pas
        self.next = (Piece(random.randint(1,min(self.nb_niveaux,self.niveaux_debloque-1)),-1,-2),
                     Piece(random.randint(1,min(self.nb_niveaux,self.niveaux_debloque-1)),-1,-1))
        self.observer.ajouter(self.next[0],self.next[1])
        self.nouvelle_piece()
        self.fin=False

    #cree 2 nouvelles pieces
    def nouvelle_piece(self):
        self.pos = [3,True]
        self.score += self.score_tmp
        self.score_tmp = 3**(self.next[0].forme-1) + 3**(self.next[1].forme-1)       
        self.next[0].deplacer_en(3,9)
        self.next[1].deplacer_en(4,9)
        self.tableau[3][9] = self.next[0]
        self.tableau[4][9] = self.next[1]
        self.next = (Piece(random.randint(1,min(self.nb_niveaux,self.niveaux_debloque-1)),-1,-1),
                     Piece(random.randint(1,min(self.nb_niveaux,self.niveaux_debloque-1)),-1,-2))
        self.observer.ajouter(self.next[0],self.next[1])
        self.observer.afficher()

    #jouer un coup
    def jouer_coup(self):
        if not self.fin:
            self.reduire_tableau([])
            self.fin = self.perdu()
            if not self.fin:
                self.nouvelle_piece()
            else:
                self.observer.fin()
                
    #reduit le tableau au maximum en faisant tomber les pieces
    #et en reduisant les groupes
    def reduire_tableau(self,pieces):
        pieces += self.tomber_pieces()
        changements = []
        for piece in pieces:
            if piece.forme not in [0,12]:
                changements += self.verifier_piece(piece)
        self.observer.afficher()
        for piece in changements:
            piece.demarquer()
        if len(changements) > 0:
            self.enchainements += 1
            if self.enchainements > 1 :
                self.score += (self.enchainements-1) * 10
            self.reduire_tableau(changements)
        self.enchainements = 0

    #test si la piece a plus de 3 voisins identiques et renvoie le nouvel elemen
    def verifier_piece(self,arg_piece):
        time = self.observer.time.get_ticks()
        pieces = self.groupe_forme(arg_piece)
        if len(pieces) >= 3:
            pieces.sort(lambda x,y : x.ord == y.ord and cmp(x.abs, y.abs) or not x.ord == y.ord and cmp(x.ord, y.ord))
            piece = pieces[0]
            self.score += (3-len(pieces))*(3**(piece.forme-1))
            self.niveaux_debloque = max(piece.forme+1,self.niveaux_debloque)
            piece.changer_forme(piece.forme+1,time)
            for piece in pieces[1:]:
                piece.supprimer(time)
                self.tableau[piece.abs][piece.ord] = None
            return [pieces[0]]
        else:
            for piece in pieces:
                piece.demarquer()
            return []

    #fais tomber toutes les pieces et renvoie toutes les pieces bougees
    def tomber_pieces(self):
        time = self.observer.time.get_ticks()
        num_col = 0
        res = []
        for colonne in self.tableau:
            haut = 0
            for i in range(11):
                if colonne[i]!=None:
                    if i != haut:
                        colonne[haut] = colonne[i]
                        colonne[i] = None
                        colonne[haut].descendre(i-haut,time)
                        res.append(colonne[haut])
                    haut += 1
            num_col += 1
        self.observer.afficher()
        return res
    
    #test si la partie est perdu
    def perdu(self):
        for y in range(7,9):
            for x in range(7):
                if self.tableau[x][y] != None:
                    return True
        return False

    #renvoie le groupe adjacent de piece de la meme forme
    def groupe_forme(self,arg_piece):
        arg_piece.marquer()
        res = [arg_piece]
        x = arg_piece.abs
        y = arg_piece.ord
        forme = arg_piece.forme
        if x>0:
            piece = self.tableau[x-1][y]
            if piece!=None and piece.forme==forme and not piece.mark:
                res += self.groupe_forme(piece)
        if x<6:
            piece = self.tableau[x+1][y]
            if piece!=None and piece.forme==forme and not piece.mark:
                res += self.groupe_forme(piece)
        if y>0:
            piece = self.tableau[x][y-1]
            if piece!=None and piece.forme==forme and not piece.mark:
                res += self.groupe_forme(piece)
        if y<10:
            piece = self.tableau[x][y+1]
            if piece!=None and piece.forme==forme and not piece.mark:
                res += self.groupe_forme(piece)
        return res    

    def bouger_gauche(self):
        time = self.observer.time.get_ticks()
        if self.pos[0] > 0:
            x = self.pos[0]
            if self.pos[1]:
                self.tableau[x][9].gauche(time)
                self.tableau[x-1][9] = self.tableau[x][9]
                self.tableau[x+1][9].gauche(time)
                self.tableau[x][9] = self.tableau[x+1][9]
                self.tableau[x+1][9] = None
            else:
                self.tableau[x][9].gauche(time)
                self.tableau[x-1][9] = self.tableau[x][9]
                self.tableau[x][9] = None
                self.tableau[x][10].gauche(time)
                self.tableau[x-1][10] = self.tableau[x][10]
                self.tableau[x][10] = None
            self.observer.afficher()
            self.pos[0] -= 1
            
    def bouger_droite(self):
        time = self.observer.time.get_ticks()
        if self.pos[0] < 5 or not self.pos[1] and self.pos[0] < 6:
            x = self.pos[0]
            if self.pos[1]:
                self.tableau[x+1][9].droite(time)
                self.tableau[x+2][9] = self.tableau[x+1][9]
                self.tableau[x][9].droite(time)
                self.tableau[x+1][9] = self.tableau[x][9]
                self.tableau[x][9] = None
            else:
                self.tableau[x][9].droite(time)
                self.tableau[x+1][9] = self.tableau[x][9]
                self.tableau[x][9] = None
                self.tableau[x][10].droite(time)
                self.tableau[x+1][10] = self.tableau[x][10]
                self.tableau[x][10] = None
            self.observer.afficher()
            self.pos[0] += 1

    def tourner(self):
        time = self.observer.time.get_ticks()
        x = self.pos[0]
        if self.pos[1]:
            self.tableau[x][9].haut(time)
            self.tableau[x][10] = self.tableau[x][9]
            self.tableau[x+1][9].gauche(time)
            self.tableau[x][9] = self.tableau[x+1][9]
            self.tableau[x+1][9] = None
        else:
            if x < 6:
                self.tableau[x][9].maj(time)
                self.tableau[x][10].tourner(time)
                self.tableau[x+1][9] = self.tableau[x][10]
                self.tableau[x][10] = None
            else:
                self.tableau[x][9].gauche(time)
                self.tableau[x-1][9] = self.tableau[x][9]
                self.tableau[x][10].bas(time)
                self.tableau[x][9] = self.tableau[x][10]
                self.tableau[x][10] = None
                self.pos[0] -= 1
        self.observer.afficher()
        self.pos[1] = not self.pos[1]


