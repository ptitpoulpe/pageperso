#!/usr/bin/env python2.7
# -*- coding: utf-8 -*-
import math, utils

class Stats(object):
    """ Make stats of a set of answer

        http://alpage.inria.fr/%7Esagot/pub/TALN06a.pdf
    """

    max_powersets = 3

    def __init__(self, results, score, ex_formes,
                       smooth=False, powersets=False,
                       ps_func=lambda x:utils.powerset(x, Stats.max_powersets)):
        """ results: array of results
            score: function of scoring
            ex_formes: function for extract forms from result
            rep_dict: dict for replace some tags
        """
        self.sijs = [] # sucpicion rate of each entry with list of forms in it
        self.ofs = {} # dict of form with score of each occurence
        self.sfs = {} # dict of average sucpicion rate for each form
        self.sfns = {} # dict of average sucpicion rato for powerset form
        self.S = 0
        self.smooth = smooth
        self.powersets = powersets
        self.ps_func = ps_func
        self.nb_loops = 0

        if self.powersets:
            for res in results:
                formes = ex_formes(res)
                if formes:
                    err = score(res)
                    for s in filter(None, self.ps_func(formes)):
                        sfn = self.sfns.setdefault(frozenset(s), [0,0])
                        sfn[0 if err else 1] += 1
            for sfn, (nb_occ_err, nb_occ_noerr) in self.sfns.items():
                self.sfns[sfn].append(nb_occ_err/(nb_occ_err+nb_occ_noerr))      

        errs = 0
        nb_formes = 0
        for res in results:
            formes = ex_formes(res)
            if formes:
                if powersets:
                    formes = self.expand_formes(formes)
                err = score(res)
                errs += err
                nb_formes += len(formes)
                #print formes
                #print len(formes)
                err_m = err/len(formes)
                p = []
                for f in formes:
                    p.append(f)
                    self.ofs.setdefault(f, []).append(err_m)
                self.sijs.append((err, p))
        self.S = errs/nb_formes

    def expand_formes(self, formes):
        #print "==========="
        #print len(formes)
        #print '\n'.join(formes)
        formes_ps = map(frozenset, filter(None, self.ps_func(formes)))
        used_formes = []
        alpha = 1.0
        new_formes = []
        for s1 in sorted(formes_ps, key=len, reverse=True):
            if s1 not in used_formes and \
               all(self.sfns[s1][2] > self.sfns[s2][2] * 
                                      (1 + math.exp(-alpha*self.sfns[s1][0]))
                   for s2 in formes_ps if s1>s2):
                new_formes.append(s1)
                used_formes.extend(x for x in formes_ps if s1>x)
        #print "-----------"
        #print len(new_formes)
        #print '\n'.join(new_formes) 
        return new_formes

    def smooth_sfs(self, beta=0.2):
        smooth = lambda f: 1 - math.exp(-beta*len(self.ofs[f]))
        for f in self.sfs:
            sf = smooth(f)
            self.sfs[f] = sf*self.sfs[f] + (1 - sf)*self.S

    def one_loop(self):
        self.nb_loops += 1
        save = self.sfs.copy()
        # S_f^(n+1) = 1/|O_f| * Σ_(o_(i,j) ∈ O_f) S_(i,j)^(n) 
        for f, of in self.ofs.items():
            self.sfs[f] = 1./len(of)*sum(of)
        if self.smooth:
            self.smooth_sfs()
        changes = [abs(save.get(f, 0)-self.sfs[f]) for f in self.sfs]
        self.ofs.clear()
        # S_(i,j)^(n+1) = erreur(p_i) * S_(F_(O_(i,j)))^(n+1) /  S_i^(n+1)
        for err, p in self.sijs:
            # S_i^(n+1) = Σ_(1≤j≤|p_i|) S_(F_(O_(i,j)))^(n+1)
            ssnf = sum(self.sfs[f] for f in p)
            for f in p:
                r = err*self.sfs[f]/ssnf if err!=0. else err
                self.ofs.setdefault(f, []).append(r)
        return sum(changes)/len(changes)

    def multi_loop(self, n=10):
        for i in range(n):
            self.one_loop()

    def until_loop(self, c=0.002):
        while self.one_loop()>c: pass
        return self.nb_loops

    def print_nbest(self, n=20, w=False):
        wf = lambda k, v: v*(math.log(len(self.ofs[k])) if w else 1)
        for k, v in sorted(self.sfs.items(), 
                           key=lambda x: wf(x[0],x[1]),
                           reverse=True)[:n]:
            s = '%.10f, %10f: '%(wf(k,v),v) if w else '%.10f: '%(v)
            print '%s%s'%(s, ('\n'+' '*len(s)).join(k) 
                              if isinstance(k,frozenset) else k)

    def latex_nbest(self, n=20, w=False, split=lambda x:x):
        wf = lambda k, v: v*(math.log(len(self.ofs[k])) if w else 1)
        res = ['\\begin{tabular}{|c|c|c|}\\hline\n']
        for e, (k, v) in enumerate(sorted(self.sfs.items(), 
                                          key=lambda x: wf(x[0],x[1]),
                                          reverse=True)[:n]):
            format = lambda x: x if False and isinstance(x, unicode) else \
                               ' & '.join(split(x)) 
            elems = list(k) if isinstance(k,frozenset) else [k]
            res.append('%s & %s & %.5f\\\\'%(e+1, format(elems[0]), wf(k, v)))
            for e in elems[1:]:
                res.append('\n & %s & \\\\'%format(e))
            res.append('\\hline\n')
        res.append('\\end{tabular}\n')
        return ''.join(res)


