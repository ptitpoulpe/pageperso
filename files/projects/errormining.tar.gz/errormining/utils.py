#!/usr/bin/env python2.6
# -*- coding: utf-8 -*-
from itertools import *

def inuplets(list, size=2):
    """ inuplets([0, 1, 2, 3, 4]) 
         => [(0, 1), (2, 3)] """
    return izip(*[iter(list)]*size)

def icombinations(listss):
    """ combinations([[1,2],[3,4]]) 
         => [(1, 3), (2, 3), (1, 4), (2, 4)] """
    if len(listss)==1:
        for l in listss[0]:
            yield (l,)
        return
    for c in icombinations(listss[1:]):
        for l in listss[0]:
            yield (l,)+c
    return 

def ipacket(it, size=5):
    """ ipacket([0, 1, 2, 3, 4, 5, 6, 7, 8, 9], 3)
        => [[0, 1, 2], [3, 4, 5], [6, 7, 8], [9]]"""
    res = []
    for e in it:
        if len(res)==size:
            yield res
            res = [e]
        else:
            res.append(e)
    if res:
        yield res

def powerset(iterable, max=0):
    """powerset([1,2,3])
       => () (1,) (2,) (3,) (1,2) (1,3) (2,3) (1,2,3)"""
    s = list(iterable)
    if max==0: max = len(s)
    return chain.from_iterable(combinations(s, r) for r in range(max+1))

def adjust_rep(rep, size):
    """adjust the repartition to fit on the size"""
    krep = None
    if isinstance(rep, dict):
        krep, rep = zip(*rep.items())
    sum_rep = sum(rep)
    frep = [int(float(r)/sum_rep*size) for r in rep]
    while sum(frep)!=size:
        i, j = min(enumerate(fr/r for r, fr in zip(rep, frep)),
                   key=lambda x: x[1])
        frep[i] += 1
    if krep is None:
        return frep
    else:
        return dict(zip(krep, frep))

def suites_ents2testsuite(suites_ents, size=None,
                          ents_rep=None, suites_rep=None):
    """ 

        suites_ents: {'suite_name': ([no_ents],[ents])}
        size       : int
        ents_rep   : {True: percent, False: percent}
        suites_rep : {'suite_name': percent}
    """
    import json
    from random import sample
    # compute the max size if it doesn't exists
    if size is None:
        size = sum( len(ents[True]) + len(ents[False])
                    for ents in suites_ents.values())
    # compute ents_rep if it doesn't exists
    if ents_rep is None:
        e, n = map(sum, zip(*( (len(ents[True]), len(ents[False])) 
                               for ents in suites_ents.values())))
        ents_rep = {True: e, False: n}
    # compute suites_rep if it doesn't exists
    if suites_rep is None:
        suites_rep = dict((s, len(ents[True]) + len(ents[False])) 
                          for s, ents in suites_ents.items())
    suites_rep = adjust_rep(suites_rep, size)
    print json.dumps( dict( (s, dict((e,len(ents[e])) for e in ents))
                          for s, ents in suites_ents.items()), indent=4)
    print json.dumps( dict((s, len(ents[True]) + len(ents[False])) 
                          for s, ents in suites_ents.items()), indent=4)
    print json.dumps(suites_rep, indent=4)
    # get the base repartition
    suites_ents_rep = {}
    # if some rep is impossible get what miss
    miss_ents = {True: 0, False:0}
    full = [] 
    for suite_name, suite_len in suites_rep.items():
        loc_ents_rep = {True : len(suites_ents[suite_name][True]),
                        False: len(suites_ents[suite_name][False])}
        suites_ents_rep[suite_name] = {True: 0, False:0}
        for ent_type, ent_len in adjust_rep(ents_rep, suite_len).items():
            if ent_len > loc_ents_rep[ent_type]:
                r = loc_ents_rep[ent_type]
                miss_ents[ent_type] += ent_len - loc_ents_rep[ent_type]
                suites_ents_rep[suite_name][not ent_type] += ent_len - loc_ents_rep[ent_type]
                full.append( (suite_name,ent_type) )
            else:
                r = ent_len
            suites_ents_rep[suite_name][ent_type] += r
    print json.dumps(suites_ents_rep, indent=4)
    # add miss ents to unfull parts        
    while sum(miss_ents.values()):
        print miss_ents
        new_miss_ents = {True: 0, False:0}
        ents_suites_rep = {True: {}, False:{}}
        for suite_name, vals in suites_ents_rep.items():
            for ent_type, rep in vals.items():
                if (suite_name, ent_type) not in full:
                    ents_suites_rep[ent_type][suite_name] = rep
        for ent_type, vals in ents_suites_rep.items():
            new_len = sum(vals.values()) + miss_ents[ent_type]
            print '-----'
            print json.dumps(vals)
            print json.dumps(adjust_rep(vals, new_len))
            for suite_name, rep in adjust_rep(vals, new_len).items():
                ste_len = len(suites_ents[suite_name][ent_type])
                if rep > ste_len:
                    r = ste_len
                    new_miss_ents[ent_type] += rep - ste_len
                    full.append( (suite_name,ent_type) )
                else:
                    r = rep
                b = vals[suite_name]
                suites_ents_rep[suite_name][ent_type] += r - b
                suites_ents_rep[suite_name][not ent_type] -= r - b
        miss_ents = new_miss_ents
        print json.dumps(suites_ents_rep, indent=4)

    pairs = []
    for suite_name, r_ents_rep in suites_ents_rep.items():
        for ent_type, rep in r_ents_rep.items():
            for ent in sample(suites_ents[suite_name][ent_type], rep):
                pairs.append(ent)
#    print pairs
    return pairs

import re
# predicates to omit
omit_preds = set(['progressive', 'passive', 'comp', 'mod'])
# background knowledge
imps = [('the' , ['a']),
        ('bill', ['a', 'man']),
        ('lisa', ['a', 'woman'])]
def word_overlap(t,h):
    "test if a non entailment is too easy to recognize"
    t_sem = set(re.findall(r'\w+:(\w+)\(.*?\)', t))# - omit_preds
    h_sem = set(re.findall(r'\w+:(\w+)\(.*?\)', h))# - omit_preds
    imps = [('the' , ['a']),
            ('bill', ['a','man'])]
    #print t['sent']
    #print h['sent']
    for i, j in imps:
        if i in t_sem:
            for k in j:
                t_sem.add(k)
    #print bool(h_sem - t_sem)
    return float(len(h_sem & t_sem)) / len(h_sem)

def word_overlap_correlations(pairs):
    corres_yes = []
    corres_no  = []
    for pair in pairs:
        wo = word_overlap(pair['T']['sem'], pair['H']['sem'])
        if pair['ent']=='YES':
            corres_yes.append(wo)
        else:
            corres_no.append(1 - wo)
    print (sum(corres_yes)/len(corres_yes) + sum(corres_no)/len(corres_no))/2

