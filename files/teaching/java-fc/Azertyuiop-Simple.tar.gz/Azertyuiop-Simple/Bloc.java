
public class Bloc {

	static int nbPieces;
	protected int numero;
	protected Bloc sur;
	protected Bloc porte;
	
	Bloc(){
		numero = Bloc.nbPieces++;
	}
	
	void vaEn(Bloc dest){
		if (porte != null)// Dégagement du Cube receveur
			porte.vaEn(null);
		if (sur != null) // Si on est sur un cube on le libère
			sur.quiJePorte(null);
		
		if (dest != null) { // Si le destinataire n'est pas la table
			if (dest.quiJePorte() != null) // Si le destinataire n'est pas libre
				dest.quiJePorte().vaEn(null); // on le dégage
			dest.quiJePorte(this);
		}
		
		sur = dest;
	}
	
	
	public Bloc quiJePorte(){ return this.porte; }
	public Bloc quiJePorte(Bloc porte){	return this.porte = porte; }
	
	public Bloc quiMePorte(){ return this.sur; }
	public Bloc quiMePorte(Bloc sur){ return this.sur = sur; }
	
	public int numero() {return numero;}
	
	public void quiJeSuis(){
		System.out.println("Je suis le cube " + numero + ".");
		if (this.sur == null)
			System.out.println("Je suis sur la table");
		else 
			System.out.println("Je suis sur le cube " + this.sur.numero() + ".");

		if (this.porte != null)
			System.out.println("Je porte le cube " + this.porte.numero() + ".");
	}

	
	public static void main(String[] args){
		Bloc a = new Bloc();
		Bloc b = new Bloc();
		Bloc c = new Bloc();
		Bloc d = new Bloc();
		a.vaEn(b);
		c.vaEn(d);
		a.quiJeSuis();
		c.quiJeSuis();
		b.vaEn(d);
		d.quiJeSuis();
	}
}
