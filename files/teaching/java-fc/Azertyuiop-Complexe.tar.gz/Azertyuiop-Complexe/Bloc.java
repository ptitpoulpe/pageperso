

/**
 * @author  shenshei
 */
abstract class Bloc extends Piece implements Deplacable{

	protected Porteur sur;
	
	public void vaEn(Porteur dest) {
		// A Remplir: deplacement d'un bloc Deplacable
	}
	
	public Porteur quiMePorte() {return sur;}
	public Porteur quiMePorte(Porteur sur) {return this.sur = sur; }
}
