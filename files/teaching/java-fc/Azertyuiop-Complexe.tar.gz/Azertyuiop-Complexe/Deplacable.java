interface Deplacable {
	public void vaEn(Porteur dest);
}
