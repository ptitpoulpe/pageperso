

public class Pyramide extends Bloc {

	Pyramide() {
		// A Remplir : Initialisation
	}
	
	public void quiJeSuis() {
		// A Remplir : Qui Je Suis
	}
	
	public void nomNom() {
		// A Remplir: mon nom
	}

}
