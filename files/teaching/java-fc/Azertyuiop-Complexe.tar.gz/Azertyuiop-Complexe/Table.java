

public final class Table extends Piece implements Porteur {

	Table() {
		numero = 0; //ce numero permet de la distinguer
	}
	
	public void quiJeSuis(){
		// A Remplir: qui je suis
	}
	
	public void nomNom() {
		// A Remplir: mon nom
	}
	
	public Deplacable quiJePorte() {
		return null; //porte tout donc rien
	}
	
	public Deplacable quiJePorte(Deplacable porte) {
		return null; // porte tout donc rien
	}
}
