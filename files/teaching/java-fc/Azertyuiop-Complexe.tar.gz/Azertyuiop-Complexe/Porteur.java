interface Porteur {
	public Deplacable quiJePorte();
	public Deplacable quiJePorte(Deplacable porte);
}