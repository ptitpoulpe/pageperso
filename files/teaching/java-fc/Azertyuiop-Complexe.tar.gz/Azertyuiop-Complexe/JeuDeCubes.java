

/**
 * @author  shenshei
 */
public class JeuDeCubes {

	static Table laTable;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		laTable = new Table();
		Cube c1 = new Cube(); // 2
		Cube c2 = new Cube(); // 3
		Cube c3 = new Cube(); // 4
		Pyramide p1 = new Pyramide(); // 5
		Pyramide p2 = new Pyramide(); // 6
		
		c1.vaEn(c3);
		p1.vaEn(c1);
		p2.vaEn(c2);
		
		// 5
		// 2 6
		// 4 3
		
		c1.quiJeSuis();
		c3.quiJeSuis();
	}

}
