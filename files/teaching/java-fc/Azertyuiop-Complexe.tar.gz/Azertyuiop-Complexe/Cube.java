

/**
 * @author  shenshei
 */
public class Cube extends Bloc implements Porteur {

	Deplacable porte;
	
	Cube(){
		// A Remplir: Initialisation
	}
	
	public void quiJeSuis() {
		// A Remplir: Qui Je Suis
	}
	
	public void nomNom() {
		// A Remplir: mon nom
	}

	public Deplacable quiJePorte() { return porte; }

	public Deplacable quiJePorte(Deplacable porte) { return this.porte = porte;	}

	public void vaEn(Cube dest) {
		// A Remplir: Deplacement d'un cube deplacable et porteur
	}

	
}
