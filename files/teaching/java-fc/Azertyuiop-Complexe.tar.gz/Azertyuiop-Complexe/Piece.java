
abstract class Piece {
	protected static int nbPieces = 1;
	protected int numero;
	public int numero() {return numero;}
	abstract public void quiJeSuis();
	abstract public String monNom();
}
