/**
 * Cette application \'ecrit la date du jour
 * en toutes lettres (e.g. lundi 1 janvier 2007)
 */
import java.util.Date;
import java.text.SimpleDateFormat;

class DateDuJour {
	public static void main(String[] args) {
		// creer la date du jour
		Date dateDuJour;
		dateDuJour = new Date();
		// creer son modele de presentation
		SimpleDateFormat fd;
		fd = new SimpleDateFormat("EEEE dd MMMM yyyy");
		// afficher la date du jour selon ce modele
		System.out.println(fd.format(dateDuJour));
	}
}
