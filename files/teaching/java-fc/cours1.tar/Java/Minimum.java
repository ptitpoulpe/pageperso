public class Minimum{
	public static void main(String[] args){
	}
}
