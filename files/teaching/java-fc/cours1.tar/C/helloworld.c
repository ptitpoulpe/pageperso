#include <stdio.h>
main() {
    puts("Hello World");
    return 0;
}
