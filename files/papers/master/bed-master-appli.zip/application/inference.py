from racer import Racer
import re,os

############################################
#Classe representant un individu d'une abox#
############################################
class Entity:
    def __init__(self,name):
        self.name = name
        self.roles = []
        self.inv_roles = []
        self.attributes = []
        self.direct_types = []
        self.associed_entitys = []

    def set_roles(self,r):
        self.roles = r

    def set_inv_roles(self,ir):
        self.inv_roles = ir

    def set_attributes(self,a):
        self.attributes = a
        
    def set_direct_types(self,dt):
        self.direct_types = dt

    def set_associed_entitys(self,ae):
        self.associed_entitys = ae

    def print_me(self):
        print "*-------------------*"
        print "Name: "+self.name
        print "Roles: "
        print self.roles
        print "Inv Roles: "
        print self.inv_roles
        print "Attributes: "
        print self.attributes
        print "Direct Types: "
        print self.direct_types
        print "Associed Entity: "
        print self.associed_entitys
        print "*-------------------*"

############################################
#Classe permettant de tester les inferences#
############################################
class Inference:
    def __init__(self):
        self.racer=Racer()
        self.entitys = {}
        self.bijection = {}
        self.unbijection = {}
        self.unassociated = {}
        self.tname = "t"
        self.hname = "h"
        self.verbose = False
        self.compteur = 0

    def close(self):
        self.racer.close

    def load_knowledge(self,knowledge):
        self.racer.multi_query(['(in-tbox c-d-b)']+knowledge+['(classify-tbox)'])

    def load_abox_tbox(self,t,h):
        self.racer.query('(clone-tbox c-d-b :new-name connaissance-de-base%s :overwrite t)'%str(self.compteur))
        self.racer.multi_query(t[2]+h[2]+['(classify-tbox)'])
        self.racer.multi_query(['(in-abox %s connaissance-de-base%s)'%(self.tname,str(self.compteur))]+t[1]+['(prepare-racer-engine)','(realize-abox)'])
        self.racer.multi_query(['(in-abox %s connaissance-de-base%s)'%(self.hname,str(self.compteur))]+h[1]+['(prepare-racer-engine)','(realize-abox)'])  

    #teste une inference entre 2 abox decrites dans un fichier
    def infAA(self,t,h,verbose=False):
        self.compteur += 1
        self.tname = "t" + str(self.compteur)
        self.hname = "h" + str(self.compteur)
        self.verbose = verbose
        self.load_abox_tbox(t,h)
        self.create_entitys_list()
        self.get_associed_entitys()
        if not self.part_entitys() :
            return False
        return self.test_fs()

    #fonction qui recupere la liste des entity d'une abox
    def create_entitys_list(self):
        self.entitys.clear()
        #on cree les differentes Entitys
        #on recupere les infos dessus
        #et on recupere les Entitys associes qui ont les memes concepts
        for individual in self.racer.all_individuals(self.hname):
            #on ajoute l'individu a la liste
            e = Entity(individual)
            self.entitys[individual] = e
            #on recupere les infos de l'entite
            e.set_roles(self.racer.all_role_in_domain(individual,self.hname))
            e.set_inv_roles(self.racer.all_role_in_range(individual,self.hname))
            e.set_direct_types(self.racer.individual_direct_types(individual,self.hname))

    #fonction qui recupere les entitys asocies a une entity
    def get_associed_entitys(self):
        for e in self.entitys.values():
            #on recuperes les Entitys associes
            ae = self.racer.concept_instances(self.racer.And(e.direct_types),
                                              self.tname)
            e.set_associed_entitys(ae)
            if self.verbose :
                e.print_me()
            
    #fonction qui recupere les entitys liees a une seul entity
    #et les entitys liees a plusieurs 
    def part_entitys(self):
        self.bijection.clear()
        self.unbijection.clear()
        self.unassociated.clear()
        for name,e in self.entitys.items():
            lenght = len(e.associed_entitys)
            #on a une entity sans entity associe
            #donc l'implication est fausse
            if lenght == 0:
                self.unassociated[name] = e
            #on recupere la liste des entitys qui ont
            #une bijection
            elif lenght == 1:
                self.bijection[name] = e.associed_entitys[0]
            #on recupere la liste des entitys qui ont
            #plus d'une entity associe
            elif lenght > 1:
                self.unbijection[name] = e
        return len(self.bijection) + len(self.unbijection) > 0

    #on test si la bijection est bonne dans la premiere abox
    def test_f(self):
        for name,e in self.entitys.items():
            #on test les relations sur les noeuds qui ont une bijection
            if self.bijection.has_key(name):
                assoc_name = self.bijection[name]
                for role in e.roles:
                    if self.bijection.has_key(role[1]):
                        if self.verbose:
                            print assoc_name+" "+role[0]+" "+self.bijection[role[1]]
                        if not self.racer.individuals_related(assoc_name,
                                                              role[0],
                                                              self.bijection[role[1]],
                                                              self.tname) :
                            return False
            else:#si un des noeuds de la relation n'est pas associe
                roles = []
                #on recupere la liste de tous les roles et roles inverses
                #attaches au noeud
                for role in e.roles:
                    #si le noeud n'est pas relie a un noeud
                    #ayant une bijectionon retourne false
                    if not self.bijection.has_key(role[1]):
                        return False                   
                    roles.append(("(some (inv %s) (and %s))" % (role[0]," ".join(e.direct_types))
                                  ,self.bijection[role[1]]))
                for role in e.inv_roles:                                  
                    #si le noeud n'est pas relie a un noeud
                    #ayant une bijectionon retourne false
                    if not self.bijection.has_key(role[1]):
                        return False                   
                    roles.append(("(some %s (and %s))" % (role[0]," ".join(e.direct_types))
                                  ,self.bijection[role[1]]))

                if len(roles)<=0:
                    return False
                #on test pour toules roles si le noeud existe
                for concept, i in roles:
                    if self.verbose:
                        print i+" "+concept
                    if not self.racer.individual_instance(i,concept,self.tname) :
                        return False
        return True

    #fonction qui cherche toutes les bijections possibles
    #puis qui les teste
    def test_fs(self):
        #on prend une des entitys incomplete
        try:
            name,entity_unbij = self.unbijection.popitem()
        except:
            #bijection finie il faut lancer le test
            if self.verbose :
                print self.bijection
            i = self.test_f()
            if self.verbose :
                print i
            return i

        for asso in entity_unbij.associed_entitys:
            #on ajoute l'association a la liste des entitys
            #et on relance la fonction
            self.bijection[name] = asso
            #si on a True on return True sinon on continue
            if self.test_fs() :
                return True
            #on supprime l'entree du dico
            del self.bijection[name]

        #on a pas trouve de bijection, on remet le incomplete
        #et on relance l'algo
        self.unbijection[name] = entity_unbij
        return False

    #cree le graphe representant la ABox implique
    def make_graph(self,nom):
        nom = re.sub('[ .,\']','_',nom)
        f = file('graphes/%s.dot'%nom,'w')
        f.write('digraph G {\n')
        f.write(' node [shape=Mrecord];\n')
        for entity in self.entitys.values():
            f.write('%s [label="%s|%s"];\n'%(entity.name,
                                             entity.name,
                                             " ".join(entity.direct_types)) )
            for role in entity.roles:
                f.write('%s -> %s [label="%s"];\n'%(entity.name,
                                                    role[1],
                                                    role[0]) )
        f.write('}')
        f.close()
        os.popen('dot graphes/%s.dot -Tpng -o graphes/%s.png'%(nom,nom)) 
            
        
