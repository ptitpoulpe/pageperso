#!/usr/bin/env python
import xml.dom.minidom
from xml import xpath
from inference import Inference

class Application:
    #fonction d'initialisation de l'application
    def __init__(self):
        self.i = Inference()

    #fonction qui test un ensemble de couple de textes
    #avec une connaissance de base donnee
    def test_entailment_with_kb(self,entailment,knowledge,filtre=[],verbose=False,graph=False):
        entailment = xml.dom.minidom.parse(entailment)
        knowledge = self.get_kbrules(xml.dom.minidom.parse(knowledge).getElementsByTagName('knowledge')[0])

        pairs = self.get_pairs(entailment,filtre)

        self.i.load_knowledge(knowledge)
        for pair in pairs:
            answer,t,h = pair
            print '#'*50
            print 'T:'+t[0]
            print 'H:'+h[0]
            print 'T->H (%s): %s'%(answer[0],self.i.infAA(t,h,verbose))
            if graph:
                self.i.make_graph(h[0])
            print 'H->T (%s): %s'%(answer[1],self.i.infAA(h,t,verbose))
            if graph:
                self.i.make_graph(t[0])

    #cree un tableau contenant les regles de la connaissance de base
    def get_kbrules(self,node):
        rules = []
        for rule in node.getElementsByTagName('r'):
            rules.append(rule.childNodes[0].data)
        return rules

    #cree un tableau des couples de phrases du corpus et de leur traduciton en dl
    def get_pairs(self,entailment,filtre=[]):
        pairs = []
        if filtre==[]:
            filtre = ''
        else:
            filtre = '[@id="%s"]'%'" or @id="'.join(filtre)
            
        for pair in xpath.Evaluate('//pair%s'%filtre,entailment):
            value = pair.getAttribute('value')
            answers = (value == 'equiv' or value == 'impl',
                      value == 'equiv')

            t = pair.getElementsByTagName('t')[0]
            abox, tbox = self.make_abox_tbox('t',
                                             self.get_individuals(t.getElementsByTagName('dl')[0]),
                                             self.get_relations(t.getElementsByTagName('dl')[0]))
            t = (t.getElementsByTagName('fr')[0].childNodes[0].data,abox,tbox)

            h = pair.getElementsByTagName('h')[0]
            abox, tbox = self.make_abox_tbox('h',
                                             self.get_individuals(h.getElementsByTagName('dl')[0]),
                                             self.get_relations(h.getElementsByTagName('dl')[0]))
            h = (h.getElementsByTagName('fr')[0].childNodes[0].data,abox,tbox)    

            pairs.append( (answers,t,h) )
            
        return pairs
    
    #a partir d une liste des individus et des relations
    #cree la abox et la tbox correspondante
    def make_abox_tbox(self,name,inds,roles):
        abox = []
        tbox = []
        sign = ' '
        for ind in inds:
            iname = name + ind[0]
            cname = 'c-' + iname
            cdef = ind[1]
            sign += iname + ' '
            tbox.append('(equivalent %s %s)'%(cname,cdef) )
            abox.append('(instance %s %s)'%(iname,cname) )
        for role in roles:
            role = (name + role[0],name + role[1],role[2])
            abox.append('(related %s %s %s)'%role )
        abox = ['(signature :individuals (%s))'%sign] + abox
        return (abox,tbox)

    #cree un tableau des individus de la abox
    def get_individuals(self,node):
        inds = []
        for ind in node.getElementsByTagName('ind'):
            inds.append( (ind.getAttribute('name'),
                          ind.childNodes[0].data) )       
        return inds

    #cree un tableau des relations de la abox
    def get_relations(self,node):
        roles = []
        for role in node.getElementsByTagName('rel'):
            roles.append( (role.getAttribute('from'),
                           role.getAttribute('to'),
                           role.getAttribute('name')) )        
        return roles



a = Application()
a.test_entailment_with_kb('entailment-corpus-fr-en.xml',
                          'connaissance-de-base.xml',filtre=['test'])

