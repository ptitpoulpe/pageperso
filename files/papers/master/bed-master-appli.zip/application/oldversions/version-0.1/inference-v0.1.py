#!/usr/bin/env python
import socket, re

############################################
#Classe representant un individu d'une abox#
############################################
class Entity:
    def __init__(self,name):
        self.name = name
        self.roles = []
        self.inv_roles = []
        self.attributes = []
        self.direct_types = []
        self.associed_entitys = []

    def set_roles(self,r):
        self.roles = r

    def set_inv_roles(self,ir):
        self.inv_roles = ir

    def set_attributes(self,a):
        self.attributes = a
        
    def set_direct_types(self,dt):
        self.direct_types = dt

    def set_associed_entitys(self,ae):
        self.associed_entitys = ae

    def print_me(self):
        print "*-------------------*"
        print "Name: "+self.name
        print "Roles: "
        print self.roles
        print "Inv Roles: "
        print self.inv_roles
        print "Attributes: "
        print self.attributes
        print "Direct Types: "
        print self.direct_types
        print "Associed Entity: "
        print self.associed_entitys
        print "*-------------------*"


#############################################
#Classe permettant de communiquer avec racer#
#############################################
class Racer:
    def __init__(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect(('127.0.0.1', 8088))

    def close(self):
        self.socket.close()

    #fonction qui envoie des demandes a racer et qui recupere la reponse
    def query(self,msg):
        #changer la regexp pour matcher l'erreur
        self.socket.send(msg+"\n")
        res = self.socket.recv(1024)
        print 'Msg:**%s**'%msg
        print 'Res:**%s**'%res
        return re.match(":(answer|error|ok) (\d*) (?:\"(.*?)\")?.*", res).groups()

    ###########################
    #LES DIFFERENTES QUESTIONS#
    ###########################
    
    #recupere les individus d'une abox
    def all_individuals(self,abox=""):
        res = self.query("(all-individuals %s)" % abox)
        if res[0]=="error":
            return []
        elif res[0]=="answer":
            return self.parse_individuals(res[2])

    #recupere les instances d'une liste de concepts
    def concept_instances(self,concepts,abox=""):
        concepts = " ".join(concepts)
        res = self.query("(concept-instances (and %s) %s)" % (concepts,abox))
        if res[0]=="error":
            return []
        elif res[0]=="answer":
            return self.parse_individuals(res[2])

    #recupere toutes les infos sur un individu
    def describe_individual(self,name,abox=""):
        res = self.query("(describe-individual %s %s)" % (name,abox))
        res = re.match("\(.* :ASSERTIONS .* :ROLE-FILLERS (.*) :TOLD-ATTRIBUTE-FILLERS (.*) :DIRECT-TYPES (.*)\)", res[2]).groups()
        return [self.parse_roles(res[0]),
                self.parse_inv_roles(res[0]),
                self.parse_attributes(res[1]),
                self.parse_direct_types(res[2])]

    #recupere les concepts de base d'un individu
    def individual_direct_types(self,name,abox=""):
        res = self.query("(individual-direct-types %s %s)" % (name,abox))
        if res[0]=="error":
            return []
        elif res[0]=="answer":
            return self.parse_direct_types(res[2])

    #test si deux individus sont relies par une relation
    def individuals_related(self,i1,r,i2,abox=""):
        res = self.query("(individuals-related-p %s %s %s %s)" % (i1,i2,r,abox))
        if res[0]=="error":
            return False
        elif res[0]=="answer":
            return res[2]=="T"

    #charge un fichier dans racer
    def read_file(self,filename):
        if 'ok' != self.query("(racer-read-file \"%s\")" % filename)[0]:
            print "Erreur du chargement du fichier : %s" % filename
        

    ##########################
    #LES DIFFERENTS PARSSAGES#
    ##########################

    #parse les attributs A FAIRE
    def parse_attributes(self,msg):
        return []

    #parse les concepts de base
    def parse_direct_types(self,msg):
        return re.findall("[\w-]+", msg)

    #parse les individus
    def parse_individuals(self,msg):
        if msg == "NIL" :
            return []
        else:
            return re.findall("[\w-]+", msg)

    #parse les roles inveses
    def parse_inv_roles(self,msg):
        if msg == "NIL" :
            return []
        else:
            roles = re.findall("\(\(INV ([\w-]+)\) \(([\w -]+)\)\)", msg)
            res = []
            for role in roles:
                entitys = role[1].split(" ")
                for entity in entitys:
                    res.append( (role[0],entity) )
            return res
        
    #parse les roles
    def parse_roles(self,msg):
        if msg == "NIL" :
            return []
        else:
            roles = re.findall("\(([\w-]+) \(([\w -]+)\)\)", msg)
            res = []
            for role in roles:
                entitys = role[1].split(" ")
                for entity in entitys:
                    res.append( (role[0],entity) )
            return res


##########################################
#Classe perettan de tester les inferences#
##########################################
class Inference:
    def __init__(self):
        self.racer=Racer()
        self.entitys = {}
        self.bijection = {}
        self.unbijection = {}
        self.unassociated = {}
        self.ab1 = ""
        self.ab2 = ""
        self.verbose = False

    def close(self):
        self.racer.close

    #teste une inference entre 2 abox decrites dans un fichier
    def infAA(self,filename,ab1,ab2,verbose=False):
        self.verbose = verbose
        self.racer.read_file(filename)
        self.ab1 = ab1
        self.ab2 = ab2
        self.create_entitys_list()
        self.get_associed_entitys()
        if not self.get_bij_unbij() :
            return False
        return self.bijections()

    #fonction qui recupere la liste des entity d'une abox
    def create_entitys_list(self):
        self.entitys.clear()
        #on cree les differentes Entitys
        #on recupere les infos dessus
        #et on recupere les Entitys associes qui ont les memes concepts
        for individual in self.racer.all_individuals(self.ab2):
            #on ajoute l'individu a la liste
            e = Entity(individual)
            self.entitys[individual] = e
            #on recupere les infos de l'entite
            desc = self.racer.describe_individual(individual,self.ab2)
            e.set_roles(desc[0])
            e.set_inv_roles(desc[1])
            e.set_attributes(desc[2])
            e.set_direct_types(desc[3])

    #fonction qui recupere les entitys asocies a une entity
    def get_associed_entitys(self):
        for e in self.entitys.values():
            #on recuperes les Entitys associes
            ae = self.racer.concept_instances(e.direct_types,self.ab1)
            e.set_associed_entitys(ae)
            if self.verbose :
                e.print_me()
            
    #fonction qui recupere les entitys liees a une seul entity
    #et les entitys liees a plusieurs 
    def get_bij_unbij(self):
        self.bijection.clear()
        self.unbijection.clear()
        self.unassociated.clear()
        for name,e in self.entitys.items():
            lenght = len(e.associed_entitys)
            #on a une entity sans entity associe
            #donc l'implication est fausse
            if lenght == 0:
                self.unassociated[name] = e
            #on recupere la liste des entitys qui ont
            #une bijection
            elif lenght == 1:
                self.bijection[name] = e.associed_entitys[0]
            #on recupere la liste des entitys qui ont
            #plus d'une entity associe
            elif lenght > 1:
                self.unbijection[name] = e
        return len(self.bijection) + len(self.unbijection) > 0

    #on test si la bijection est bonne dans la premiere abox
    def test_boxes(self):
        for name,e in self.entitys.items():
            assoc_name = self.bijection[name]
            for role in e.roles:
                if self.verbose:
                    print assoc_name+" "+role[0]+" "+self.bijection[role[1]]
                if not self.racer.individuals_related(assoc_name,
                                                      role[0],
                                                      self.bijection[role[1]],
                                                      self.ab1) :
                    return False
        return True

    #fonction qui cherche toutes les bijections possibles
    #puis qui les teste
    def bijections(self):
        #on prend une des entitys incomplete
        try:
            name,entity_unbij = self.unbijection.popitem()
        except:
            #bijection finie il faut lancer le test
            if self.verbose :
                print self.bijection
            i = self.test_boxes()
            if self.verbose :
                print i
            return i

        for asso in entity_unbij.associed_entitys:
            #on ajoute l'association a la liste des entitys
            #complete si elle n'est pas deja associe a une autre entity
            #et on relance la fonction
            if asso not in self.bijection.values():
                self.bijection[name] = asso
                #si on a True on return True sinon on continue
                if self.bijections() :
                    return True
                #on supprime l'entree du dico
                del self.bijection[name]

        #on a pas trouve de bijection, on remet le incomplete
        #et on relance l'algo
        self.unbijection[name] = entity_unbij
        return False


i = Inference()
#quelques tests
#decommenter les ,True) pour avoir la verbose
print "test.racer : %s" % i.infAA("test.racer","jean-vr","jean-br")#,True)
print "test2.racer : %s" % i.infAA("test2.racer","a1","a2")#,True)
print "test3.racer (a1=>a2): %s" % i.infAA("test3.racer","a1","a2")#,True)
print "test3.racer (a1=>a3): %s" % i.infAA("test3.racer","a1","a3")#,True)
print "test3.racer (a2=>a1): %s" % i.infAA("test3.racer","a2","a1")#,True)
i.close()


