#!/usr/bin/env python
import xml.dom.minidom
from inference import Inference

def get_rules(node):
    rules = []
    for rule in node.getElementsByTagName('r'):
        rules.append(rule.childNodes[0].data)
    return rules

def get_pairs(entailment):
    pairs = []
    for pair in entailment.getElementsByTagName('pair'):
        value = pair.getAttribute('value')
        answers = (value == 'equiv' or value == 'impl',
                  value == 'equiv')

        t = pair.getElementsByTagName('t')[0]
        t = (t.getElementsByTagName('fr')[0].childNodes[0].data,
             get_rules(t.getElementsByTagName('dl')[0]))

        h = pair.getElementsByTagName('h')[0]
        h = (h.getElementsByTagName('fr')[0].childNodes[0].data,
             get_rules(h.getElementsByTagName('dl')[0]))        

        pairs.append( (answers,t,h) )
        
    return pairs


entailment = xml.dom.minidom.parse('entailment-corpus-fr-en.xml')
knowledge = get_rules(xml.dom.minidom.parse('connaissance-de-base.xml').getElementsByTagName('knowledge')[0])

pairs = get_pairs(entailment)

i = Inference()
i.load_knowledge(knowledge)
for pair in pairs:
    answer,t,h = pair
    print '#'*15
    print 'T:'+t[0]
    print 'H:'+h[0]
    print 'T->H (%s): %s'%(answer[0],i.infAA(t[1],h[1]))
    #decommenter la ligne pour creer les images des graphes
    #i.make_graph(h[0])
    print 'H->T (%s): %s'%(answer[1],i.infAA(h[1],t[1]))
    #decommenter la ligne pour creer les images des graphes
    #i.make_graph(t[0])
