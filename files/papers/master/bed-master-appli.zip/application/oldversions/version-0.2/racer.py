import socket, re, os  

#############################################
#Classe permettant de communiquer avec racer#
#############################################
class Racer:
    def __init__(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.connect(('127.0.0.1', 8088))
        self.error = 'Racer Error'
        self.warnings = False

    def close(self):
        self.socket.close()

    def multi_query(self,msgs):
        for msg in msgs:
            self.query(msg)
        
    #fonction qui envoie des demandes a racer et qui recupere la reponse
    def query(self,msg):
        self.socket.send(re.sub('\n','',msg)+"\n")
        res = self.socket.recv(1024)
        if res == '':
            return None
        res = re.match(':(answer|error|ok) (\d*) (.*)', res).groups()
        if res[0] == 'answer':
            answer = re.match('"(.*)" "(.*)"',res[2]).groups()
            if self.warnings and answer[1]!='':
                print "***WARNING*** "+res[1]+" "+answer[1]
            return answer[0]
        elif res[0] == 'ok':
            ok = re.match('"(.*)"',res[2]).groups()
            if self.warnings and ok[0]!='':
                print "***WARNING*** "+res[1]+" "+ok[0]
        elif res[0] == 'error':
            error = re.match('(.*) "(.*)"',res[2]).groups()
            if error[1]=="":
                res = '"'+res[1]+':'+error[0]+'"'
            else:
                res = '"'+error[0]+". "+error[1]+'"'
            raise self.error,res

    ######################################
    #LES FONCTIONS QUI SIMPLIFIENT LA VIE#
    ######################################

    #fonction qui prend une liste de conceptes et qui fais un 'and' dessus
    def And(self,args):
        return '(and '+' '.join(args)+')'

    #fonction qui prend une liste de conceptes et qui fais un 'or' dessus
    def Or(self,args):
        return '(or '+' '.join(args)+')'

    ###########################
    #LES DIFFERENTES QUESTIONS#
    ###########################
    
    #recupere les individus d'une abox
    def all_individuals(self,abox=""):
        res = self.query("(all-individuals %s)" % abox)
        return self.parse_individuals(res)

    #recupere ma liste entites lies par un role
    def all_role_assertions(self,abox=""):
        res = self.query("(all-role-assertions %s)" % abox)
        return self.parse_role_assertions(res)

    #recupere la liste des roles associes a un individu
    def all_role_in_domain(self,name,abox=""):
        res = self.query('(all-role-assertions-for-individual-in-domain %s %s)'%(name,abox))
        roles = []
        for role in self.parse_roles(res):
            roles.append((role[2],role[1]))
        return roles
    
    #recupere la liste des roles inverses associes a un individu
    def all_role_in_range(self,name,abox=""):
        res = self.query('(all-role-assertions-for-individual-in-range %s %s)'%(name,abox))
        roles = []
        for role in self.parse_roles(res):
            roles.append((role[2],role[0]))
        return roles

    #recupere les instances d'une liste de concepts
    def concept_instances(self,concept,abox=""):
        res = self.query("(concept-instances %s %s)" % (concept,abox))
        return self.parse_individuals(res)

    #recupere toutes les infos sur un individu
    def describe_individual(self,name,abox=""):
        res = self.query("(describe-individual %s %s)" % (name,abox))
        res = re.match("\(.* :ASSERTIONS .* :ROLE-FILLERS (.*) :TOLD-ATTRIBUTE-FILLERS (.*) .* :DIRECT-TYPES (.*)\)", res[2:-2]).groups()
        return [self.parse_roles(res[0]),
                self.parse_inv_roles(res[0]),
                self.parse_attributes(res[1]),
                self.parse_direct_types(res[2])]

    #recupere les concepts de base d'un individu
    def individual_direct_types(self,name,abox=""):
        res = self.query("(individual-direct-types %s %s)" % (name,abox))
        return self.parse_direct_types(res)

    #test si un individus est une instance du concept
    def individual_instance(self,i,c,abox=""):
        res = self.query("(individual-instance-p %s %s %s)" % (i,c,abox))
        return res=="T"

    #test si deux individus sont relies par une relation
    def individuals_related(self,i1,r,i2,abox=""):
        res = self.query("(individuals-related-p %s %s %s %s)" % (i1,i2,r,abox))
        return res=="T"

    #charge un fichier dans racer
    def read_file(self,filename):
        self.query("(racer-read-file \"%s\")" % os.path.abspath(filename))
        

    ##########################
    #LES DIFFERENTS PARSSAGES#
    ##########################

    #parse les attributs A FAIRE
    def parse_attributes(self,msg):
        return []

    #parse les concepts de base
    def parse_direct_types(self,msg):
        return re.findall("[\w-]+", msg)

    #parse les individus
    def parse_individuals(self,msg):
        if msg == "NIL" :
            return []
        else:
            return re.findall("[\w-]+", msg)

    #parse les roles
    def parse_roles(self,msg):
        if msg == "NIL" :
            return []
        else:
            roles = re.findall("\(\(([\w-]+) ([\w-]+)\) ([\w-]+)\)", msg)
            return roles

    def parse_role_assertions(self,msg):
        if msg == "NIL" :
            return []
        else:
            return re.findall('\(\(([\w-]+) ([\w-]+)\) ([\w-]+)\)', msg)
        
